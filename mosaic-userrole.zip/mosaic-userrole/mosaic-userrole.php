<?php
/**
 * Plugin Name: mosaic user role
 * Version: 0.7
 * Description: This plugin requires symbol-api plugin.
 * License: GPL ver.2 or later
 */

require dirname( __FILE__ ) . '/mosaics.php';
require dirname( __FILE__ ) . '/settings-api.php';
require dirname( __FILE__ ) . '/user-role-change.php';
require dirname( __FILE__ ) . '/user-wallet.php';

